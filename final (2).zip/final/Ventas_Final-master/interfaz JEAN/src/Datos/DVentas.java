/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

/**
 *
 * @author MASTER
 */
public class DVentas {
    String Nombre;
    String Apellido;
    String Tipo_Pago;
    String Costo;
    String Abono;
    String Saldo;
    String TelefonoC;
    String CedulaC;
    String TelefonoM;
    String Codigo;
    String Productos;
    String Numero_Producto;
    String Tipo_Tratamiento;
    public DVentas(){
        
    }

    public String getTipo_Tratamiento() {
        return Tipo_Tratamiento;
    }

    public void setTipo_Tratamiento(String Tipo_Tratamiento) {
        this.Tipo_Tratamiento = Tipo_Tratamiento;
    }

    public String getNumero_Producto() {
        return Numero_Producto;
    }

    public void setNumero_Producto(String Numero_Producto) {
        this.Numero_Producto = Numero_Producto;
    }

    public String getProductos() {
        return Productos;
    }

    public void setProductos(String Productos) {
        this.Productos = Productos;
    }
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getTipo_Pago() {
        return Tipo_Pago;
    }

    public void setTipo_Pago(String Tipo_Pago) {
        this.Tipo_Pago = Tipo_Pago;
    }

    public String getCosto() {
        return Costo;
    }

    public void setCosto(String Costo) {
        this.Costo = Costo;
    }

    public String getAbono() {
        return Abono;
    }

    public void setAbono(String Abono) {
        this.Abono = Abono;
    }

    public String getSaldo() {
        return Saldo;
    }

    public void setSaldo(String Saldo) {
        this.Saldo = Saldo;
    }

    public String getTelefonoC() {
        return TelefonoC;
    }

    public void setTelefonoC(String TelefonoC) {
        this.TelefonoC = TelefonoC;
    }

    public String getCedulaC() {
        return CedulaC;
    }

    public void setCedulaC(String CedulaC) {
        this.CedulaC = CedulaC;
    }

    public String getTelefonoM() {
        return TelefonoM;
    }

    public void setTelefonoM(String TelefonoM) {
        this.TelefonoM = TelefonoM;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }
    
    
}
