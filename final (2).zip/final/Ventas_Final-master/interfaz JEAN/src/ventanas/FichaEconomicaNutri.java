package ventanas;

import com.mysql.jdbc.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class FichaEconomicaNutri extends javax.swing.JFrame {

    String fecha = "";
    String cedula = "";
    String codtrata = "";

    public FichaEconomicaNutri() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setTitle("ASENUT - Gestion de Ficha Cosmetologica");
        this.setIconImage(new ImageIcon(getClass().getResource("/imagenes/logoASENUTbarra.PNG")).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtSaldo = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtAbono = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtTotal = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        cbxTipoPago = new javax.swing.JComboBox();
        txtFecha = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar2 = new javax.swing.JMenuBar();
        btnGuardar = new javax.swing.JMenu();
        btnRegresar = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setText("Fecha de Pago: ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, -1, -1));

        jLabel3.setText("Saldo Disponible: ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, -1, -1));

        txtSaldo.setEditable(false);
        txtSaldo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtSaldoKeyTyped(evt);
            }
        });
        getContentPane().add(txtSaldo, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 80, 210, 30));

        jLabel4.setText("Cantidad a Abonar:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, -1));

        txtAbono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtAbonoKeyTyped(evt);
            }
        });
        getContentPane().add(txtAbono, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 140, 210, 30));

        jLabel5.setText("Costo Total:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, -1, -1));

        txtTotal.setEditable(false);
        txtTotal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTotalKeyReleased(evt);
            }
        });
        getContentPane().add(txtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 270, 210, 30));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 400, 10));

        jLabel6.setText("Forma De Pago:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, -1));

        getContentPane().add(cbxTipoPago, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, 210, 30));

        txtFecha.setDateFormatString("yyyy-MM-dd");
        getContentPane().add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, 210, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jLabel1.setName("ficha"); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 320));

        jMenuBar2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Save.png"))); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGuardarMouseClicked(evt);
            }
        });
        jMenuBar2.add(btnGuardar);

        btnRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        btnRegresar.setText("Regresar");
        btnRegresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegresarMouseClicked(evt);
            }
        });
        jMenuBar2.add(btnRegresar);

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/minimize-icon-17_2.png"))); // NOI18N
        jMenu1.setText("Minimizar");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar2.add(jMenu1);

        setJMenuBar(jMenuBar2);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGuardarMouseClicked
        PreparedStatement cmd;
        ResultSet rs;
        double abono = Double.parseDouble(txtAbono.getText());
        int codpago = 0;
        int cont = 0;
        double saldo = Double.parseDouble(txtSaldo.getText());
        String total = txtTotal.getText();
        String tipo = cbxTipoPago.getSelectedItem().toString();
        String fdia = "";
        String fmes = "";
        if (txtFecha.getCalendar().get(Calendar.DAY_OF_MONTH) <= 9) {
            fdia = "0" + txtFecha.getCalendar().get(Calendar.DAY_OF_MONTH);
        } else {
            fdia = String.valueOf(txtFecha.getCalendar().get(Calendar.DAY_OF_MONTH));
        }

        if ((txtFecha.getCalendar().get(Calendar.MONTH) + 1) <= 9) {
            fmes = "0" + ((txtFecha.getCalendar().get(Calendar.MONTH) + 1));
        } else {
            fmes = String.valueOf((txtFecha.getCalendar().get(Calendar.MONTH) + 1));
        }
        String fechi = "'" + txtFecha.getCalendar().get(Calendar.YEAR) + "-" + fmes + "-" + fdia + "'";

        if (tipo.equalsIgnoreCase("Efectivo")) {
            codpago = 1;
        } else if (tipo.equalsIgnoreCase("Cheque")) {
            codpago = 2;
        } else if (tipo.equalsIgnoreCase("Tarjeta Credito")) {
            codpago = 3;
        }

        if (abono > saldo) {
            JOptionPane.showMessageDialog(null, "No puede abonar más de lo que debe");
        } else {
            try {
                rs = Conexion.link.createStatement().executeQuery("SELECT * FROM FICHA_ECONOMICA");
                while (rs.next()) {
                    cont++;
                }
                cont += 1;
                saldo = saldo - abono;
                //////////////////////////////////////////////////
                cmd = (PreparedStatement) Conexion.link.prepareStatement("insert into FICHA_ECONOMICA values ("
                        + cont + ", '" + fecha + "','" + cedula + "','" + codtrata
                        + "','" + codpago + "','" + total + "','" + abono + "','" + saldo + "'," + fechi + ")");
                cmd.execute();

            } catch (SQLException e) {
                System.out.println(e);
            }
        }
        this.setVisible(false);
        FichaNutricional fn = new FichaNutricional();
        fn.setVisible(true);
    }//GEN-LAST:event_btnGuardarMouseClicked

    private void btnRegresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegresarMouseClicked
        // TODO add your handling code here:
        FichaNutricional fc = new FichaNutricional();
        fc.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnRegresarMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        cargarlista();

        ResultSet rs;
        FichaNutricional fn = new FichaNutricional();

        String fecha = "";
        String cod = "";
        String ced = fn.cedulaficha;
        String nom = "'" + fn.tratamientoficha + "'";

        try {
            rs = Conexion.link.createStatement().executeQuery("SELECT TT.COD_TRATAMIENTO FROM TIPO_TRATAMIENTO TT "
                    + "WHERE TT.NOM_TRATA = " + nom);
            while (rs.next()) {
                cod = rs.getString(1);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }

        try {
            rs = Conexion.link.createStatement().executeQuery("SELECT PT.FECHA_TRATA FROM PACIENTE_TRATAMIENTO PT "
                    + "WHERE PT.CEDULA = '" + ced + "' AND PT.COD_TRATAMIENTO = " + cod);
            while (rs.next()) {
                fecha = rs.getString(1);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        System.out.println(ced + ", " + cod + ", " + nom + ", " + fecha + " fin");
        this.fecha = fecha;
        this.cedula = ced;
        this.codtrata = cod;
        int cont = 0;
        try {
            rs = Conexion.link.createStatement().executeQuery("SELECT FE.SALDO, FE.COSTO_TOTAL FROM FICHA_ECONOMICA FE "
                    + "WHERE FE.CEDULA = '" + ced + "' AND FE.COD_TRATAMIENTO = " + cod);
            while (rs.next()) {
                txtSaldo.setText(rs.getString(1));
                txtTotal.setText(rs.getString(2));
                cont++;
            }
            if (cont == 0) {
                txtTotal.setEditable(true);
                txtSaldo.setText("0");
                txtAbono.setEditable(false);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }

        double saldo = Double.parseDouble(txtSaldo.getText());
        if (saldo == 0) {
            txtAbono.setEditable(false);
        }
        if (txtTotal.isEditable()) {
            txtAbono.setEditable(true);
        }
    }//GEN-LAST:event_formWindowOpened

    private void txtSaldoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSaldoKeyTyped
        char c = evt.getKeyChar();
        if (Character.isLetter(c)) {
            evt.consume();
        }
    }//GEN-LAST:event_txtSaldoKeyTyped

    private void txtAbonoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtAbonoKeyTyped
        char c = evt.getKeyChar();
        if (Character.isLetter(c)) {
            evt.consume();
        }
    }//GEN-LAST:event_txtAbonoKeyTyped

    private void txtTotalKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTotalKeyReleased
        // TODO add your handling code here:
        if (txtTotal.isEditable()) {
            txtSaldo.setText(txtTotal.getText());
        }
    }//GEN-LAST:event_txtTotalKeyReleased

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        this.setExtendedState(ICONIFIED);
    }//GEN-LAST:event_jMenu1MouseClicked

    private void cargarlista() {
        // TODO Auto-generated method stub
        ResultSet rs;
        cbxTipoPago.removeAllItems();
        try {
            Conexion.Conectar();
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT TDP.TIPO_PAGO FROM TIPO_DE_PAGO TDP");
            while (rs.next()) {
                String tmpStrObtenido = rs.getString(1);
                cbxTipoPago.addItem(tmpStrObtenido);
            }
            Conexion.Close();
            Conexion.Conectar();
        } catch (Exception e) {
            System.out.println("ERROR: falla al cargar los trataminetos");
        }

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FichaEconomicaNutri.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FichaEconomicaNutri.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FichaEconomicaNutri.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FichaEconomicaNutri.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FichaEconomicaNutri().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu btnGuardar;
    private javax.swing.JMenu btnRegresar;
    private javax.swing.JComboBox cbxTipoPago;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField txtAbono;
    private com.toedter.calendar.JDateChooser txtFecha;
    private javax.swing.JTextField txtSaldo;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
